# TV Show Backend API

This is a comprehensive backend service for a TV show tracking application, built with Node.js, Express, and MySQL.

It provides a full suite of features including user authentication, role-based access control (admins vs. users), and a detailed data model for TV shows, seasons, episodes, and cast.

## Features

- **User Authentication:** Secure user registration and login using JWT.
- **Role-Based Access:** `admin` role for managing the TV show catalog and `user` role for personal list management.
- **Complete TV Show Data:** Endpoints to manage shows, seasons, episodes, and cast.
- **Detailed Show Information:** Get a single show with all its nested data (seasons, episodes, cast) in one request.
- **Personalized Lists:** Users can manage their own 'Favorites' and 'Watchlist'.
- **Comprehensive Search:** Search for shows by title, description, genre, or cast member.

## Getting Started

Follow these instructions to get the project set up and running on your local machine.

### Prerequisites

- [Node.js](https://nodejs.org/) (v14 or later recommended)
- [MySQL](https://www.mysql.com/downloads/)

### Installation & Setup

1.  **Clone the repository:**
    ```bash
    git clone <repository_url>
    cd <repository_directory>
    ```

2.  **Install dependencies:**
    ```bash
    npm install
    ```

3.  **Set up the database:**
    - Log in to your MySQL server.
    - Create the database and tables by running the `schema.sql` script provided in the root of the project. You can do this via a client like MySQL Workbench or from the command line:
      ```bash
      mysql -u your_username -p < schema.sql
      ```

4.  **Configure environment variables:**
    - Make a copy of the `.env.example` file and name it `.env`.
    - Open the `.env` file and fill in your specific configuration details:
      ```
      DB_HOST=your_db_host
      DB_USER=your_db_user
      DB_PASSWORD=your_db_password
      DB_NAME=tv_shows_db
      JWT_SECRET=choose_a_very_strong_secret_key
      PORT=3001
      ```

5.  **Run the server:**
    - The server uses `nodemon` to automatically restart on file changes.
    - Start the server with:
      ```bash
      npm start
      ```
    - The API will be running at `http://localhost:3001` (or whatever port you specified).

## API Endpoints Overview

- `POST /api/auth/register`: Register a new user.
- `POST /api/auth/login`: Log in and receive a JWT.

- `GET /api/shows`: Get a paginated list of all shows.
- `GET /api/shows/search?q=<term>`: Search for shows.
- `GET /api/shows/:id`: Get detailed info for one show.

- `POST /api/shows`: **(Admin only)** Create a new show.
- `PUT /api/shows/:id`: **(Admin only)** Update a show.
- `DELETE /api/shows/:id`: **(Admin only)** Delete a show.

- `GET /api/me/favorites`: **(User only)** Get user's favorite shows.
- `POST /api/me/favorites`: **(User only)** Add a show to favorites.
- `DELETE /api/me/favorites/:showId`: **(User only)** Remove a show from favorites.

- `GET /api/me/watchlist`: **(User only)** Get user's watchlist.
- `POST /api/me/watchlist`: **(User only)** Add a show to watchlist.
- `DELETE /api/me/watchlist/:showId`: **(User only)** Remove a show from watchlist.
