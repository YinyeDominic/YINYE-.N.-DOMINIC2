const db = require('../config/database');

// --- Public Controllers ---

// Get all shows with pagination
exports.getAllShows = async (req, res) => {
  const page = parseInt(req.query.page, 10) || 1;
  const limit = parseInt(req.query.limit, 10) || 10;
  const offset = (page - 1) * limit;

  try {
    const [shows] = await db.query('SELECT * FROM shows LIMIT ? OFFSET ?', [limit, offset]);
    res.json(shows);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

// Get a single show with all its nested details
exports.getShowById = async (req, res) => {
  const { id } = req.params;
  try {
    // 1. Get main show details
    const [shows] = await db.query('SELECT * FROM shows WHERE id = ?', [id]);
    if (shows.length === 0) {
      return res.status(404).json({ msg: 'Show not found' });
    }
    const show = shows[0];

    // 2. Get seasons and their episodes
    const [seasons] = await db.query('SELECT * FROM seasons WHERE show_id = ? ORDER BY season_number', [id]);
    for (const season of seasons) {
      const [episodes] = await db.query('SELECT * FROM episodes WHERE season_id = ? ORDER BY episode_number', [season.id]);
      season.episodes = episodes;
    }
    show.seasons = seasons;

    // 3. Get cast
    const [cast] = await db.query(
      `SELECT a.id, a.name, a.photo_url, sc.character_name 
       FROM actors a 
       JOIN show_cast sc ON a.id = sc.actor_id 
       WHERE sc.show_id = ?`,
      [id]
    );
    show.cast = cast;

    res.json(show);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

// Search for shows by title, genre, or cast
exports.searchShows = async (req, res) => {
  const { q } = req.query;
  if (!q) {
    return res.status(400).json({ msg: 'Search query is required' });
  }

  const searchTerm = `%${q}%`;

  try {
    const [shows] = await db.query(
      `SELECT DISTINCT s.* FROM shows s
       LEFT JOIN show_cast sc ON s.id = sc.show_id
       LEFT JOIN actors a ON sc.actor_id = a.id
       WHERE s.title LIKE ?
       OR s.description LIKE ?
       OR s.genre LIKE ?
       OR a.name LIKE ?`,
      [searchTerm, searchTerm, searchTerm, searchTerm]
    );
    res.json(shows);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};


// --- Admin Controllers ---

exports.createShow = async (req, res) => {
  const { title, description, release_year, genre } = req.body;
  if (!title) {
    return res.status(400).json({ msg: 'Title is required' });
  }

  try {
    const [result] = await db.query(
      'INSERT INTO shows (title, description, release_year, genre) VALUES (?, ?, ?, ?)',
      [title, description, release_year, genre]
    );
    const [newShow] = await db.query('SELECT * FROM shows WHERE id = ?', [result.insertId]);
    res.status(201).json(newShow[0]);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

exports.updateShow = async (req, res) => {
  const { id } = req.params;
  const { title, description, release_year, genre } = req.body;

  try {
    const [result] = await db.query(
      'UPDATE shows SET title = ?, description = ?, release_year = ?, genre = ? WHERE id = ?',
      [title, description, release_year, genre, id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ msg: 'Show not found' });
    }

    const [updatedShow] = await db.query('SELECT * FROM shows WHERE id = ?', [id]);
    res.json(updatedShow[0]);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

exports.deleteShow = async (req, res) => {
  const { id } = req.params;
  try {
    const [result] = await db.query('DELETE FROM shows WHERE id = ?', [id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ msg: 'Show not found' });
    }
    res.json({ msg: 'Show deleted successfully' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};
