const db = require('../config/database');

// --- Favorites Controller Logic ---

exports.getFavoriteShows = async (req, res) => {
  try {
    const [favorites] = await db.query(
      `SELECT s.* FROM shows s
       JOIN user_favorites uf ON s.id = uf.show_id
       WHERE uf.user_id = ?`,
      [req.user.id]
    );
    res.json(favorites);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

exports.addFavoriteShow = async (req, res) => {
  const { showId } = req.body;
  try {
    // Using INSERT IGNORE to prevent errors if the entry already exists
    await db.query('INSERT IGNORE INTO user_favorites (user_id, show_id) VALUES (?, ?)', [req.user.id, showId]);
    res.status(201).json({ msg: 'Show added to favorites' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

exports.removeFavoriteShow = async (req, res) => {
  const { showId } = req.params;
  try {
    await db.query('DELETE FROM user_favorites WHERE user_id = ? AND show_id = ?', [req.user.id, showId]);
    res.json({ msg: 'Show removed from favorites' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};


// --- Watchlist Controller Logic ---

exports.getWatchlist = async (req, res) => {
  try {
    const [watchlist] = await db.query(
      `SELECT s.* FROM shows s
       JOIN user_watchlist uw ON s.id = uw.show_id
       WHERE uw.user_id = ?`,
      [req.user.id]
    );
    res.json(watchlist);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

exports.addShowToWatchlist = async (req, res) => {
  const { showId } = req.body;
  try {
    await db.query('INSERT IGNORE INTO user_watchlist (user_id, show_id) VALUES (?, ?)', [req.user.id, showId]);
    res.status(201).json({ msg: 'Show added to watchlist' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

exports.removeShowFromWatchlist = async (req, res) => {
  const { showId } = req.params;
  try {
    await db.query('DELETE FROM user_watchlist WHERE user_id = ? AND show_id = ?', [req.user.id, showId]);
    res.json({ msg: 'Show removed from watchlist' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};
