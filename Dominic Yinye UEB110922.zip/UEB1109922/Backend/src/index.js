require('dotenv').config();
const express = require('express');
const cors = require('cors');
const db = require('./config/database');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Basic Route
app.get('/', (req, res) => {
  res.send('TV Show API is running...');
});

// Define routes
app.use('/api/auth', require('routes/authRoutes'));
app.use('/api/shows', require('./routes/showRoutes'));
app.use('/api/me', require('./routes/userRoutes'));

const authRoutes = require('routes/authRoutes');
app.use('/api/auth', authRoutes);

const PORT = process.env.PORT || 3000;

// Check database connection and start server
db.getConnection()
  .then(connection => {
    console.log('Successfully connected to the database.');
    connection.release();
    app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
    });
  })
  .catch(error => {
    console.error('Error connecting to the database:', error);
    process.exit(1);
  });
app.get('/api/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development'
  });
});
