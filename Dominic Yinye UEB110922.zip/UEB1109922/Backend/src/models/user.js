const db = require('../config/database');
const bcrypt = require('bcryptjs');

class User {
  /**
   * Finds a user by their username or email.
   * @param {string} username - The username to search for.
   * @param {string} email - The email to search for.
   * @returns {Promise<Array>} A promise that resolves to an array of user objects.
   */
  static async findByUsernameOrEmail(username, email) {
    const [users] = await db.query('SELECT * FROM users WHERE username = ? OR email = ?', [username, email]);
    return users;
  }

  /**
   * Creates a new user in the database after hashing their password.
   * @param {object} newUser - An object containing user details { username, email, password, role }.
   * @returns {Promise<object>} A promise that resolves to the result of the database insertion.
   */
  static async create(newUser) {
    const { username, email, password, role } = newUser;
    
    // Hash password
    const salt = await bcrypt.genSalt(10);
    const password_hash = await bcrypt.hash(password, salt);

    // Save user to database
    const userToSave = { username, email, password_hash, role: role || 'user' };
    const [result] = await db.query('INSERT INTO users SET ?', userToSave);
    return result;
  }

  /**
   * Finds a single user by their email address.
   * @param {string} email - The email of the user to find.
   * @returns {Promise<object|null>} A promise that resolves to the user object or null if not found.
   */
  static async findByEmail(email) {
    const [users] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
    if (users.length > 0) {
      return users[0];
    }
    return null;
  }
}

module.exports = User;
