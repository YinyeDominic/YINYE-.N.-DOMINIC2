const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const authMiddleware = require('../middleware/authMiddleware');

// All routes here are protected and start with /api/me

// --- Favorites Routes ---
router.get('/favorites', authMiddleware, userController.getFavoriteShows);
router.post('/favorites', authMiddleware, userController.addFavoriteShow);
router.delete('/favorites/:showId', authMiddleware, userController.removeFavoriteShow);

// --- Watchlist Routes ---
router.get('/watchlist', authMiddleware, userController.getWatchlist);
router.post('/watchlist', authMiddleware, userController.addShowToWatchlist);
router.delete('/watchlist/:showId', authMiddleware, userController.removeShowFromWatchlist);

module.exports = router;
