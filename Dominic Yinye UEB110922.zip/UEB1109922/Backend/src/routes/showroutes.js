const express = require('express');
const router = express.Router();
const showController = require('../controllers/showController');
const authMiddleware = require('../middleware/authMiddleware');
const adminMiddleware = require('../middleware/adminMiddleware');

// --- Public Routes ---

// @route   GET api/shows
// @desc    Get all shows
// @access  Public
router.get('/', showController.getAllShows);

// @route   GET api/shows/search
// @desc    Search for shows
// @access  Public
router.get('/search', showController.searchShows);

// @route   GET api/shows/:id
// @desc    Get a single show by ID with all details
// @access  Public
router.get('/:id', showController.getShowById);


// --- Admin-Only Routes ---

// @route   POST api/shows
// @desc    Create a new show
// @access  Admin
router.post('/', [authMiddleware, adminMiddleware], showController.createShow);

// @route   PUT api/shows/:id
// @desc    Update a show
// @access  Admin
router.put('/:id', [authMiddleware, adminMiddleware], showController.updateShow);

// @route   DELETE api/shows/:id
// @desc    Delete a show
// @access  Admin
router.delete('/:id', [authMiddleware, adminMiddleware], showController.deleteShow);


module.exports = router;
