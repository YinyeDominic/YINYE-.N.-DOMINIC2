const current = {
    location:window.location.pathname, 
    search:{
      term:'', 
      type:'', 
      page:1, 
      total_pages : 1, 
      total_results:0
    }, 
    api:{
      apiKey:"7263b42c2f3b766212faf1b3bdb49a9e", 
      apiUrl: 'https://api.themoviedb.org/3/'
    }
}
const ul = document.querySelector('ul'); 


//changing colours on active links
function activeColor(){
    const headerName = ul.firstElementChild.firstElementChild; 
    headerName.style.color = 'yellow'; 
}
function activeColor2(){
    const headerName = ul.lastElementChild.firstElementChild; 
    headerName.style.color = 'yellow'; 
}


//fecthing api's

async function FetchAPI(endpoint) {
    const API_KEY = current.api.apiKey; 
    const API_URL = current.api.apiUrl; 
    showSpinner();
    const fetching =await fetch(`${API_URL}${endpoint}?api_key=${API_KEY}& language=en-US`)
    const data = fetching.json(); 
    
    hideSpinner(); 
    return data 
}

//searvhing fetching data
async function searchApi() {
    const API_KEY = current.api.apiKey; 
    const API_URL = current.api.apiUrl; 
    showSpinner();
    const fetching =await fetch(`${API_URL}search/${current.search.type}?api_key=${API_KEY}& language=en-US&query=${current.search.term}&page=${current.search.page}`)
    const data = fetching.json(); 
    
    hideSpinner(); 
    return data 
}


async function popularMovie(){
    const {results}= await FetchAPI('movie/popular'); 
    console.log(results);
    results.forEach(movie =>{
        const div = document.createElement('div'); 
        div.classList.add('card'); 
        div.innerHTML =`
        <div class="card">
          <a href="movie-details.html?id=${movie.id}">
            ${
                movie.poster_path ? `

                <img
                  src="https://image.tmdb.org/t/p/w500${movie.poster_path}"
                  class="card-img-top"
                  alt="${movie.title}"
                />` : `
                
                <img
                src="images/no-image.jpg"
                class="card-img-top"
                alt="${movie.title}"
              /> 
                `
                
            }
          </a>
          <div class="card-body">
            <h5 class="card-title">${movie.title}</h5>
            <p class="card-text">
              <small class="text-muted">Release:${movie.release_date}</small>
            </p>
          </div>
        </div>
        `
        document.querySelector('#popular-movies').appendChild(div); 
    })
    
}
//popupalar tv shows
async function displayTvShows(){
    const {results}= await FetchAPI('tv/popular'); 
    console.log(results);
    results.forEach(tv =>{
        const div = document.createElement('div'); 
        div.classList.add('grid'); 
        div.innerHTML =`
        <div class="card">
          <a href="movie-details.html?id=${tv.id}">
            ${
                tv.poster_path ? `

                <img
                  src="https://image.tmdb.org/t/p/w500${tv.poster_path}"
                  class="card-img-top"
                  alt="${tv.name}"
                />` : `
                
                <img
                src="images/no-image.jpg"
                class="card-img-top"
                alt="${tv.name}"
              /> 
                `
                
            }
          </a>
          <div class="card-body">
            <h5 class="card-title">${tv.name}</h5>
            <p class="card-text">
              <small class="text-muted">Release:${tv.first_air_date}</small>
            </p>
          </div>
        </div>
        `
        document.querySelector('#popular-shows').appendChild(div); 
    })
    
}


async function movieDetails(){
    const movieId = window.location.search.split('=')[1]; 
    const details = await FetchAPI(`movie/${movieId}`) ; 
    displayBackdropImage('movie', details.backdrop_path); 
    const div = document.createElement('div'); 
    div.innerHTML = `
     <div class="details-top">
          <div>
          ${
            details.poster_path ? `

            <img
              src="https://image.tmdb.org/t/p/w500${details.poster_path}"
              class="card-img-top"
              alt="${details.title}"
            />` : `
            
            <img
            src="images/no-image.jpg"
            class="card-img-top"
            alt="${details.title}"
          /> 
            `
            
        }
          </div>
          <div>
            <h2>${details.title}</h2>
            <p>
              <i class="fas fa-star text-primary"></i>
              ${(details.vote_average.toFixed(1)) }/10
            </p>
            <p class="text-muted">Release Date: ${details.release_date}</p>
            <p>
              ${details.overview}
            </p>
            <h5>Genres</h5>
            <ul class="list-group">
            ${details.genres.map(genre =>
                `<li>${genre.name}</li>`
            ).join('')}
            </ul>
            <a href="#" target="_blank" class="btn">${details.homepage}</a>
          </div>
        </div>
        <div class="details-bottom">
          <h2>Movie Info</h2>
          <ul>
            <li><span class="text-secondary">Budget:</span> $${details.budget}</li>
            <li><span class="text-secondary">Revenue:</span> $${details.revenue}</li>
            <li><span class="text-secondary">Runtime:</span> ${details.runtime}</li>
            <li><span class="text-secondary">Status:</span> ${details.status}</li>
          </ul>
          <h4>Production Companies</h4>
          <div class="list-group">
          ${details.production_companies.map(company =>
            `<span>${company.name}</span>`
          ).join(', ')}
          </div>
        </div>
    `
    document.querySelector('#movie-details').appendChild(div)
    console.log(details);
}

//displays shows 
async function showDetails(){
  const showId = window.location.search.split('=')[1]; 
  const details = await FetchAPI(`tv/${showId}`) ; 
  console.log(details);
  displayBackdropImage('tv', details.backdrop_path); 
  const div = document.createElement('div'); 
  div.innerHTML = `
   <div class="details-top">
        <div>
        ${
          details.poster_path ? `

          <img
            src="https://image.tmdb.org/t/p/w500${details.poster_path}"
            class="card-img-top"
            alt="${details.name}"
          />` : `
          
          <img
          src="images/no-image.jpg"
          class="card-img-top"
          alt="${details.name}"
        /> 
          `
          
      }
        </div>
        <div>
          <h2>${details.name}</h2>
          <p>
            <i class="fas fa-star text-primary"></i>
            ${(details.vote_average.toFixed(1)) }/10
          </p>
          <p class="text-muted">Release Date: ${details.last_air_date}</p>
          <p>
            ${details.overview}
          </p>
          <h5>Genres</h5>
          <ul class="list-group">
          ${details.genres.map(genre =>
              `<li>${genre.name}</li>`
          ).join('')}
          </ul>
          <a href="#" target="_blank" class="btn">${details.homepage}</a>
        </div>
      </div>
      <div class="details-bottom">
        <h2>Movie Info</h2>
        <ul>
          <li><span class="text-secondary">Number_of_episode:</span> $${details.number_of_episodes}</li>
          <li><span class="text-secondary">Revenue:</span> $${details.last_episode_to_air.name}</li>
          <li><span class="text-secondary">Status:</span> ${details.status}</li>
        </ul>
        <h4>Production Companies</h4>
        <div class="list-group">
        ${details.production_companies.map(company =>
          `<span>${company.name}</span>`
        ).join(', ')}
        </div>
      </div>
  `
  document.querySelector('#show-details').appendChild(div)
  console.log(details);
}


//toggle spinner ; 
function showSpinner(){
    document.querySelector('.spinner').classList.add('show')
}; 
function hideSpinner(){
    document.querySelector('.spinner').classList.remove('show')
}; 
//creating a router (init app)

function displayBackdropImage(type, background){
  const div = document.createElement('div')
  div.style.backgroundImage = `url(https://image.tmdb.org/t/p/original/${background})`
  div.style.backgroundSize = 'cover'; 
  div.style.backgroundPosition = 'center'; 
  div.style.backgroundRepeat = 'no-repeat'; 
  div.style.position= 'absolute'; 
  div.style.height= '100vh'; 
  div.style.width= '100vw'; 
  div.style.top = '0'; 
  div.style.left= '0'; 
  div.style.zIndex = '-1'; 
  div.style.opacity = '0.1';
  
  if (type === 'movie'){
    document.querySelector('#movie-details').appendChild(div); 
  }
  else{
    document.querySelector('#shows-details').appendChild(div); 
  }
}

//search function 

async function search(){
  const queryString = window.location.search;
  const urlParams = new URLSearchParams(queryString);
  current.search.type =urlParams.get('type'); 
  current.search.term =urlParams.get('search-term'); 
  if(current.search.term !== '' && current.search.term !== null){
    const {results, total_pages, page, total_results} = await searchApi(); 
    current.search.page = page; 
    current.search.total_pages = total_pages;  
    current.search.total_results = total_results;  
    if(results.length === 0){
      showAlert('Input can not be empty'); 
    }
    displaySearchResults(results); 
    document.querySelector('#search-item').value = ''; 
    //make request 
  } else {
    showAlert('Please Enter an input in the search space'); 
  }
  console.log(current.search.type, current.search.term);
}


//function to display search 

function displaySearchResults(results){
  document.querySelector('#search-results-heading').innerHTML= ''; 
  document.querySelector('#search-results').innerHTML= ''; 
  document.querySelector('#pagination').innerHTML= ''; 
  results.forEach(result =>{
      const div = document.createElement('div'); 
      div.classList.add('card'); 
      div.innerHTML =`
      <div class="card">
        <a href="${current.search.type}-details.html?id=${result.id}">
          ${
              result.poster_path ? `

              <img
                src="https://image.tmdb.org/t/p/w500/${result.poster_path}"
                class="card-img-top"
                alt="${current.search.type === 'movie' ? result.title : result.name}"
              />` : `
              
              <img
              src="images/no-image.jpg"
              class="card-img-top"
              alt="${current.search.type === 'movie' ? result.title : result.name}"
            /> 
              `
              
          }
        </a>
        <div class="card-body">
          <h5 class="card-title">${current.search.type === 'movie' ? result.title : result.name}</h5>
          <p class="card-text">
            <small class="text-muted">Release:${current.search.type === 'movie' ? result.release_date : result.first_air_date}</small>
          </p>
        </div>
      </div>
      `
      document.querySelector('#search-results-heading').innerHTML =`<h2>${results.length} of ${current.search.total_results} Results for  ${current.search.term}</h2>`


      document.querySelector('#search-results').appendChild(div); 
  })
  displayPagination(); 
}


//function display pagnination

function  displayPagination(){
  const div = document.createElement('div'); 
  div.classList.add('pagination'); 
  div.innerHTML = `
  <button class="btn btn-primary" id="prev">Prev</button>
  <button class="btn btn-primary" id="next">Next</button>
  <div class="page-counter">Page ${current.search.page} of ${current.search.total_pages}</div>
`
document.querySelector('#pagination').appendChild(div); 


//disabled the prev button if we the page is one
if(current.search.page === 1){
  document.querySelector('#prev').disabled = true
}
//disabled the next button if we are on the last page
if(current.search.page === current.search.total_pages){
  document.querySelector('#next').disabled = true
}

//adding functionalities to the next button 
document.querySelector('#next').addEventListener('click', async () =>{
  current.search.page++; 
  const {results, total_pages} = await searchApi(); 
  displaySearchResults(results); 
})
document.querySelector('#prev').addEventListener('click', async () =>{
  current.search.page--; 
  const {results, total_pages} = await searchApi(); 
  displaySearchResults(results); 
})
}
//show alert 
async function showAlert(message, className){
  const alertEl = document.createElement('div'); 
  alertEl.classList.add('alert', className); 
  alertEl.appendChild(document.createTextNode(message));

  document.querySelector('#alert').appendChild(alertEl);


  setTimeout(()=>{
    alertEl.remove(); 
  }, 2000)
}

//swipper 
async function swipper(){
  const {results}=await  FetchAPI('movie/now_playing'); 
  results.forEach(movie =>{
    const div = document.createElement('div'); 
    div.classList.add('swiper-slide')
    div.innerHTML = `
        <a href="movie-details.html?id=${movie.id}">
          <img src="https://image.tmdb.org/t/p/w500${movie.poster_path}" alt="${movie.title}" />
        </a>
        <h4 class="swiper-rating">
          <i class="fas fa-star text-secondary"></i> ${movie.vote_average.toFixed(1)} / 10
        </h4>     
    `
    document.querySelector('.swiper-wrapper').appendChild(div); 
    initSwiper(); 
  })
}


function initSwiper(){
  const swiper = new Swiper('.swiper', {
    slidesPerView : 4, 
    spaceBetween : 20, 
    freeMode:true, 
    loop:true, 
    autoplay:{
      delay:4000, 
      disableOnInteraction:false
    }, 
    breakpoints:{
      500:{slidePerView:2},
      700:{slidePerView:3},
      1200:{slidePerView:4}
    },

  })
}


function init(){
    switch(current.location){
        case '/':
        case '/index.html':
            activeColor(); 
            console.log("Home");
            popularMovie(); 
            swipper(); 
        break; 
        case '/shows.html':
            activeColor2(); 
            displayTvShows();
        break; 
        case '/movie-details.html':
            movieDetails();
        break; 
        case '/search.html':
            search();
        break; 
        case '/tv-details.html':
            showDetails();
        break; 
        
    }
}

document.addEventListener('DOMContentLoaded', init); 
